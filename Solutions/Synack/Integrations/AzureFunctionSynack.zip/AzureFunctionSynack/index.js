const syncService = require('./sync-service')

module.exports = function (context, timer) {
    let timeStamp = new Date().toISOString();
    context.log(`scheduled synack synchronization is starting in the background at ${timeStamp}`)
    syncService.runSync(context)
    context.done()
}
